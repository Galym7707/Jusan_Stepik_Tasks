# Jusan_Stepik_Tasks
4 tasks from Jusan in Stepik 
