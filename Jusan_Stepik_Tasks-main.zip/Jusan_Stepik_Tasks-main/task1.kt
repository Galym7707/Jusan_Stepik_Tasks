fun Extension(number: Int): Int{
    return number * number
}
fun main (args: Array<String>) {
    print(Extension(4))
}
